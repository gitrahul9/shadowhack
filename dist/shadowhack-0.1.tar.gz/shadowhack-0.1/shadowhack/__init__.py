def shadowHack():
	return "ShadowHack!!"
