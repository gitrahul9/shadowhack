from . import shadowHack

def main()
	print shadowHack()
